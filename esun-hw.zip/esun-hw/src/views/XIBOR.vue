<template>
  <p>XIBOR</p>
  <div>
    <p>Term Rates</p>
    <TermRates
      @ratetype="getRateType"
      @rateinformation="getRateInformation"
    />
    <RateDetail :rate-type="rateTypeBean" :rate-information="rateInformation"/>
  </div>
</template>

<script>
import { ref } from 'vue'

import TermRates from "../components/TermRates.vue";
import RateDetail from "../components/RateDetail.vue";

export default {
  components: {
    TermRates,
    RateDetail,
  },
  setup() {
    const rateTypeBean = ref();
    const rateInformation = ref();

    function getRateType(obj) {
      console.log("emit test");
      console.log(obj);
      rateTypeBean.value = obj;
    }

    function getRateInformation(obj){
      console.log(obj);
      rateInformation.value = obj;
    }

    return {
      rateTypeBean,
      rateInformation,
      getRateType,
      getRateInformation,
    };
  },
};
</script>

