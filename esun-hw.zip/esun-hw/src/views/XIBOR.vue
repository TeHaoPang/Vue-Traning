<template>
  <p>XIBOR</p>
  <div>
    <p>Term Rates</p>
    <TermRates
      @ratetype="getRateType"
      @rateinformation="getRateInformation"
      @xibordata="getXiborData"
      @nextuserlist="getNextUserList"
    />
    <RateDetail
      :xibor-data="xiborData"
      :rate-type="rateTypeBean"
      :rate-information="rateInformation"
      :next-user-list="nextUserList"
    />
  </div>
</template>

<script>
import { ref, reactive } from "vue";

import TermRates from "../components/TermRates.vue";
import RateDetail from "../components/RateDetail.vue";

export default {
  components: {
    TermRates,
    RateDetail,
  },
  setup() {
    const userData = reactive({
      userID: localStorage.getItem("userID"),
      authority: localStorage.getItem("authority"),
    });
    const xiborData = ref();
    const rateTypeBean = ref();
    const rateInformation = ref();
    const nextUserList = ref();

    function getXiborData(obj) {
      xiborData.value = obj;
    }

    function getRateType(obj) {
      rateTypeBean.value = obj;
    }

    function getRateInformation(obj) {
      rateInformation.value = obj;
    }

    function getNextUserList(obj) {
      nextUserList.value = obj;
    }
    return {
      userData,
      xiborData,
      rateTypeBean,
      rateInformation,
      nextUserList,
      getXiborData,
      getRateType,
      getRateInformation,
      getNextUserList,
    };
  },
};
</script>

