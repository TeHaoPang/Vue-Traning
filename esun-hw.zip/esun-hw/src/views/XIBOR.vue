<template>
  <p>XIBOR</p>
  <div>
    <p>Term Rates</p>
    <TermRates
      :term-rate="termRate"
      @ratetype="getRateType"
      @rateinformation="getRateInformation"
      @xibordata="getXiborData"
      @nextuserlist="getNextUserList"
    />
    <RateDetail
      :flow-id="Id"
      :flow-status="flowStatus"
      :flow = "flowData"
      :xibor-data="termRate"
      :rate-type="rateTypeBean"
      :rate-information="rateInformation"
      :next-user-list="nextUserList"
    />
  </div>
</template>

<script>
import { ref, reactive, onBeforeMount } from "vue";

import TermRates from "../components/TermRates.vue";
import RateDetail from "../components/RateDetail.vue";
// import axios from "axios";

export default {
  props: { flowDetail: String, nextUsers: String },
  components: {
    TermRates,
    RateDetail,
  },
  setup(props) {
    const Id = ref();
    const flowStatus = ref();
    const flowData = ref();
    const userData = reactive({
      userID: localStorage.getItem("userID"),
      authority: localStorage.getItem("authority"),
    });
    const rateTypeBean = ref();
    const rateInformation = ref();
    const nextUserList = ref();

    const termRate = reactive({});

    onBeforeMount(() => {
      if (props.flowDetail) {
        let flowDetail = JSON.parse(props.flowDetail);
        console.log(flowDetail);
        Id.value = flowDetail.id;
        flowStatus.value = flowDetail.status;
        flowData.value = flowDetail.flow;
        Object.assign(termRate, flowDetail.termRate);
        rateInformation.value = flowDetail.rateInformation;
        rateTypeBean.value = flowDetail.rateType;
        nextUserList.value = JSON.parse(props.nextUsers);
      }
    });

    function getXiborData(obj) {
      Object.assign(termRate, obj);
    }

    function getRateType(obj) {
      rateTypeBean.value = obj;
    }

    function getRateInformation(obj) {
      rateInformation.value = obj;
    }

    function getNextUserList(obj) {
      nextUserList.value = obj;
    }

    function test() {
      console.log(props);
    }

    return {
      Id,
      flowStatus,
      flowData,
      userData,
      termRate,
      rateTypeBean,
      rateInformation,
      nextUserList,
      getXiborData,
      getRateType,
      getRateInformation,
      getNextUserList,
      test,
    };
  },
};
</script>

