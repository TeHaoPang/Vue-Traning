<template>
  <section>
    <table class="table">
      <thead>
        <tr>
          <th>案件ID</th>
          <th>Interest Rate ID</th>
          <th>Currency</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item, key) in xiborList" :key="key">
          <td>{{ item.ID }}</td>
          <td>{{ item.INTERESTRATEID }}</td>
          <td>{{ item.CURRENCY }}</td>
          <button @click="select(item.ID)">select</button>
        </tr>
      </tbody>
    </table>
  </section>
</template>

<script>
import { reactive, onBeforeMount } from "vue";
import { useStore } from "vuex";
import { useRouter } from "vue-router";
import axios from "axios";

export default {
  setup() {
    const store = useStore();
    const router = useRouter();

    const xiborList = reactive({});

    let flowList = [];

    onBeforeMount(() => {
      //TODO:之後可以加個flag去讓欄位名稱跟資料同步顯示
      axios({
        method: "GET",
        url: "http://localhost:8080/getFlowList",
        params: { userID: localStorage.getItem("userID") },
      }).then((reponse) => {
        for (let i = 0; i < reponse.data.length; i++) {
          let flag = 0;
          if (i===0){
            flowList.push(reponse.data[0]);
          }
          for (let j = 0; j < flowList.length; j++) {
            if (reponse.data[i].ID === flowList[j].ID) {
              flag = 1;
              break;
            }
          }
          if (flag === 0) {
            flowList.push(reponse.data[i]);
          }
        }
        Object.assign(xiborList, flowList);
      });
    });

    async function select(id) {
      let flowDetail = await getFlowDetail(id);
      let nextUserList = await getNextUserList();
      router.push({
        name: "XIBOR",
        params: {
          flowDetail: JSON.stringify(flowDetail),
          nextUsers: JSON.stringify(nextUserList),
        },
      });
    }

    async function getFlowDetail(flowID) {
      let flowDetail = {};
      await axios({
        method: "GET",
        url: "http://localhost:8080/getFlowDetail",
        params: { flowID: flowID },
      }).then((reponse) => {
        flowDetail = reponse.data;
      });
      return flowDetail;
    }

    async function getNextUserList() {
      let userList = {};
      if (localStorage.getItem("authority") === "經辦") {
        await axios({
          method: "GET",
          url: "http://localhost:8080/getNextUserList",
          params: { authority: "主管" },
        }).then((response) => {
          userList = response.data;
          console.log(userList);
        });
      }
      return userList;
    }
    return {
      xiborList,
      flowList,
      store,
      router,
      select,
      getFlowDetail,
    };
  },
};
</script>