import { createApp } from "vue";
import { createRouter, createWebHistory } from "vue-router";
import App from "./App.vue";
import Login from "./components/Login.vue";
import ToDoList from "./views/ToDoList.vue";
import XIBOR from "./views/XIBOR.vue";
import store from "./store.js";

const route = createRouter({
  history: createWebHistory(),
  routes: [
    { path: "/", redirect: "/login" },
    { path: "/login", component: Login },
    { path: "/todolist", component: ToDoList },
    { path: "/XIBOR", name: "XIBOR", props: true, component: XIBOR },
  ],
});

const app = createApp(App);
app.use(route);
app.use(store);
app.mount("#app");
