<template>
  <form>
    <div>
      <label for="text">Function </label>
      <select v-model="functionCode" @change="changValueDate()" name="Function">
        <option v-for="item in functionlist" :key="item.id" :value="item.value">
          {{ item.id }} : {{ item.value }}
        </option>
      </select>
    </div>
    <br />
    <div>
      <label for="text">Interest Rate ID </label>
      <select v-model="insterestRateID" name="Interest Rate ID">
        <option
          v-for="item in insterestRateList"
          :key="item.id"
          :value="item.value"
        >
          {{ item.id }} : {{ item.value }}
        </option>
      </select>
    </div>
    <br />
    <div>
      <label for="text">Currency </label>
      <select v-model="currency" name="Currency">
        <option v-for="item in currencyList" :key="item.id" :value="item.value">
          {{ item.id }} : {{ item.value }}
        </option>
      </select>
    </div>
    <br />
    <div>
      <label for="text">Value Date </label>
      <input id="date" type="date" v-model="valueDate" />
    </div>
    <br />
  </form>
  <button @click="next" type="button">Next</button>
</template>

<script>
import { ref, } from "vue";
import axios from "axios";

export default {
  emits:['ratetype','rateinformation'],
  setup(props,context) {
    const functionCode = ref("");
    const functionlist = ref([
      { id: 1, value: "Add New Value Date" },
      { id: 2, value: "Update Interest Rate" },
    ]);

    const insterestRateID = ref("");
    const insterestRateList = ref([
      { id: 1, value: "1" },
      { id: 2, value: "2" },
      { id: 3, value: "3" },
      { id: 4, value: "4" },
      { id: 5, value: "5" },
      { id: 6, value: "6" },
      { id: 7, value: "7" },
      { id: 8, value: "8" },
      { id: 9, value: "9" },
      { id: 10, value: "10" },
    ]);

    const currency = ref("");
    const currencyList = ref([
      { id: 1, value: "TWD" },
      { id: 2, value: "USD" },
      { id: 3, value: "JPY" },
      { id: 4, value: "AUD" },
      { id: 5, value: "SGD" },
    ]);

    const valueDate = ref("");

    let rateType = {};
    let rateInformationList = [];


    function changValueDate() {
      if (functionCode.value === "Add New Value Date") {
        valueDate.value = new Date().toISOString().substring(0, 10);
      }
    }

    async function next() {
      let functionString = "";
      if (functionCode.value === "Add New Value Date") {
        functionString = "1";
      } else {
        functionString = "2";
      }

      await axios({
        method: "POST",
        url: "http://localhost:8080/getTermRatedata",
        data: {
          function: functionString,
          interestRateID: insterestRateID.value,
          currency: currency.value,
          valueDate: valueDate.value,
        },
      })
        .then((response) => {
          rateType = response.data.rateType;
          rateInformationList = response.data.rateInformationList;
          
          context.emit('ratetype', rateType);
          context.emit('rateinformation', rateInformationList);
        })
        .catch((error) => {
          console.log(error);
        });
    }

    return {
      functionlist,
      functionCode,
      insterestRateID,
      insterestRateList,
      currency,
      currencyList,
      valueDate,
      changValueDate,
      next,
    };
  },
};
</script>