<template>
  <section>
    <hr />
    <p>Rate Type</p>
    <label for="text">Rate Type : {{ rateTypeString }} </label>
    <br />
    <br />
    <label for="text">Backward Type : {{ backwardTypeString }}</label>
    <br />
  </section>
  <section>
    <hr />
    <p>Rate Information</p>
    <table class="table">
      <thead>
        <tr>
          <th>Term</th>
          <th>Bid Rate %</th>
          <th>Offer Rate %</th>
          <th>K Tenor</th>
          <th>Rate %</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item, key) in rateInformationList" :key="key">
          <td>{{ item.term }}</td>
          <td><input type="text" v-model.number="item.bidRate" /></td>
          <td><input type="text" v-model.number="item.offerRate" /></td>
          <td>K{{ item.kTenor }}</td>
          <td><input type="text" v-model.number="item.rate" /></td>
        </tr>
      </tbody>
    </table>
  </section>
  <button @click="submit(rateInformationList)">Submit</button>
  <button>Delete</button>
  <button @click="authorise(rateInformationList)">Authorise</button>
</template>

<script>
import { toRefs, computed } from "vue";
import axios from "axios";

export default {
  props: { xiborData: Object, rateType: Object, rateInformation: Object },
  setup(props) {
    const ID = toRefs();
    const xibor = toRefs(props).xiborData;
    const rateTypeData = toRefs(props).rateType;
    const rateInformationList = toRefs(props).rateInformation;
    const rateTypeString = computed(() => {
      if (!rateTypeData.value) {
        return "";
      }

      if (rateTypeData.value.rateType === "1") {
        return "1.Forward Looking";
      } else if (rateTypeData.value.rateType === "2") {
        return "2.Backward Looking";
      } else {
        return "";
      }
    });
    const backwardTypeString = computed(() => {
      if (!rateTypeData.value) {
        return "";
      }

      if (rateTypeData.value.backwardType === "1") {
        return "1.Backward Average";
      } else if (rateTypeData.value.backwardType === "2") {
        return "2.Backward Overnight";
      } else {
        return "";
      }
    });

    async function submit(rateInformationList) {
      console.log(xibor.value);
      console.log(rateTypeData.value);
      console.log(rateInformationList);
      console.log(xibor.value.function);

      if (!ID.value) {
        await axios({
          method: "POST",
          url: "http://localhost:8080/submit",
          data: {
            id: "",
            termRate: xibor.value,
            rateType: rateTypeData.value,
            rateInformation: rateInformationList,
            userID: localStorage.getItem("userID"),
            status: "Wait for Authorization",
          },
        });
      } else {
        await axios({
          method: "POST",
          url: "http://localhost:8080/submit",
          data: {
            id: ID.value,
            rateInformation: rateInformationList,
            userID: localStorage.getItem("userID"),
            status: "Wait for Authorization",
          },
        });
      }
    }

    async function authorise(rateInformationList) {
      await axios({
        method: "POST",
        url: "http://localhost:8080/updateTermRatedata",
        data: {
          function: xibor.value.function,
          interestRateID: xibor.value.interestRateID,
          currency: xibor.value.currency,
          valueDate: xibor.value.valueDate,
          rateType: rateTypeData.value,
          rateInformationList: rateInformationList,
        },
      }).catch((error) => {
        console.log(error);
      });
    }

    return {
      ID,
      xibor,
      rateTypeData,
      rateTypeString,
      backwardTypeString,
      rateInformationList,
      submit,
      authorise,
    };
  },
};
</script>

