<template>
  <hr />
  <section>
    <label for="text">案件編號</label>
    <input type="text" id="flowID" v-model="Id" :placeholder="Id" />
  </section>
  <section>
    <hr />
    <p>Rate Type</p>
    <label for="text">Rate Type : {{ rateTypeString }} </label>
    <br />
    <br />
    <label for="text">Backward Type : {{ backwardTypeString }}</label>
    <br />
  </section>
  <section>
    <hr />
    <p>Rate Information</p>
    <table class="table">
      <thead>
        <tr>
          <th>Term</th>
          <th>Bid Rate %</th>
          <th>Offer Rate %</th>
          <th>K Tenor</th>
          <th>Rate %</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item, key) in rateInformationList" :key="key">
          <td>{{ item.term }}</td>
          <td><input type="text" v-model.number="item.bidRate" /></td>
          <td><input type="text" v-model.number="item.offerRate" /></td>
          <td>K{{ item.kTenor }}</td>
          <td><input type="text" v-model.number="item.rate" /></td>
        </tr>
      </tbody>
    </table>
  </section>
  <div>
    <label for="text"> 請選擇放行主管 </label>
    <select v-model="nUser" name="NextUserList">
      <option v-for="item in nextUser" :key="item.id" :value="item.USERID">
        {{ item.USERID }}
      </option>
    </select>
  </div>
  <button @click="submit(rateInformationList)">Submit</button>
  <button @click="deleteFlow">Delete</button>
  <button @click="reject">Reject</button>
  <button @click="authorise(rateInformationList)">Authorise</button>
</template>

<script>
import { ref, toRefs, computed } from "vue";
import axios from "axios";

export default {
  props: {
    flowId: String,
    flowStatus: String,
    flow:String,
    xiborData: Object,
    rateType: Object,
    rateInformation: Object,
    nextUserList: Object,
  },
  setup(props) {
    const Id = toRefs(props).flowId;
    const xibor = toRefs(props).xiborData;
    const rateTypeData = toRefs(props).rateType;
    const rateInformationList = toRefs(props).rateInformation;
    const rateTypeString = computed(() => {
      if (!rateTypeData.value) {
        return "";
      }

      if (rateTypeData.value.rateType === "1") {
        return "1.Forward Looking";
      } else if (rateTypeData.value.rateType === "2") {
        return "2.Backward Looking";
      } else {
        return "";
      }
    });
    const backwardTypeString = computed(() => {
      if (!rateTypeData.value) {
        return "";
      }

      if (rateTypeData.value.backwardType === "1") {
        return "1.Backward Average";
      } else if (rateTypeData.value.backwardType === "2") {
        return "2.Backward Overnight";
      } else {
        return "";
      }
    });
    const nextUser = toRefs(props).nextUserList;
    const nUser = ref("");

    async function submit(rateInformationList) {
      console.log(Id);
      console.log(xibor.value);
      if (!Id.value) {
        await axios({
          method: "POST",
          url: "http://localhost:8080/submit",
          data: {
            termRate: xibor.value,
            rateType: rateTypeData.value,
            rateInformation: rateInformationList,
            previousUserID: localStorage.getItem("userID"),
            userID: nUser.value,
            status: "Wait for Authorization",
          },
        });
      } else {
        await axios({
          method: "POST",
          url: "http://localhost:8080/submit",
          data: {
            id: Id.value,
            rateInformation: rateInformationList,
            previousUserID: localStorage.getItem("userID"),
            userID: nUser.value,
            flow:props.flow,
            status: "Wait for Authorization",
          },
        });
      }
    }

    async function authorise(rateInformationList) {
      console.log(rateTypeData.value);
      console.log(xibor.value.valueDate);
      await axios({
        method: "POST",
        url: "http://localhost:8080/authorise",
        data: {
          id: Id.value,
          termRate: {
            function: xibor.value.function,
            interestRateID: xibor.value.interestRateID,
            currency: xibor.value.currency,
            valueDate: xibor.value.valueDate,
          },
          rateType: rateTypeData.value,
          rateInformation: rateInformationList,
          previousUserID: localStorage.getItem("userID"),
          status: "Close",
        },
      }).catch((error) => {
        console.log(error);
      });
    }

    async function deleteFlow() {
      await axios({
        method: "GET",
        url: "http://localhost:8080/delete",
        params: { ID: Id.value },
        // data:{id:Id.value}
      });
    }

    async function reject() {
      await axios({
        method: "POST",
        url: "http://localhost:8080/reject",
        data: {
          id: Id.value,
          previousUserID: localStorage.getItem("userID"),
          userID: "ESB21662",
          status: "Edit",
        },
      });
    }

    return {
      Id,
      xibor,
      rateTypeData,
      rateTypeString,
      backwardTypeString,
      rateInformationList,
      nextUser,
      nUser,
      submit,
      authorise,
      deleteFlow,
      reject,
    };
  },
};
</script>

