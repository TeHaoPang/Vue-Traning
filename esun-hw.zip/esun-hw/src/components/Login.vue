<template>
  <section>
    <div>
      <label for="text">原編</label>
      <input type="text" id="userID" v-model="userID" />
    </div>
    <div>
      <label for="password">密碼</label>
      <input type="password" id="password" v-model="password"/>
    </div>
    <button @click="login">Login</button>
  </section>
</template>

<script>
import { ref } from "vue";
import { useStore } from "vuex";
import { useRouter } from 'vue-router';

export default {
  setup() {
    const userID = ref("");
    const password = ref("");
    const store = useStore();
    const router = useRouter();

    async function login() {
      console.log('login');
      await store.dispatch("login", {
        userID: userID.value,
        userPassword: password.value,
      });
      console.log(store.getters.getLoginState);
      if (store.getters.getLoginState){
        router.push('/todolist');
      }
      console.log('login2');
    }

    return { userID, password, login };
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
