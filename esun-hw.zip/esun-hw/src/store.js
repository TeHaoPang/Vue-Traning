import { createStore } from "vuex";
import axios from "axios";

const store = createStore({
  state() {
    return {
      userID: "",
      token: "",
      authority: "",
      isLogin: false,
    };
  },
  mutations: {
    login(state, payload) {
      state.userID = payload.userID;
      state.token = payload.token;
      state.authority = payload.authority;
      state.isLogin = payload.isLogin;
      localStorage.setItem('userID', payload.userID);
      localStorage.setItem('authority', payload.authority);
      console.log(state);
    },

  },
  actions: {
    async login(context, payload) {
      let isLogin = null;
      let password = null;
      let authority = null;
      let token = null;

      await axios({
        method: "POST",
        url: "http://localhost:8080/getlogindata",
        data: {
          userID: payload.userID,
          userPassword: payload.password,
          token: "",
          authority: "",
        },
      })
        .then((response) => {
          password = response.data.userPassword;
          authority = response.data.authority;
          token = response.data.token;
        })
        .catch((error) => {
          console.log(error);
        });

      if (payload.userPassword === password) {
        isLogin = true;
      } else {
        isLogin = false;
      }
      context.commit("login", {
        userID: payload.userID,
        token: token,
        authority: authority,
        isLogin,
      });
    },
  },
  getters: {
    getLoginState(state) {
      return state.isLogin;
    },
    getUserID(state) {
      return state.userID;
    },
    getAuthority(state) {
      return state.authority;
    },
  },
});

export default store;
