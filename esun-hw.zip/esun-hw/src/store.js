import { createStore } from "vuex";
import axios from "axios";

const store = createStore({
  state() {
    return {
      userID: "",
      token: "",
      authority: "",
      isLogin: false,
    };
  },
  mutations: {
    login(state, payload) {
      console.log("mutations");
      state.userID = payload.userID;
      state.token = payload.token;
      state.authority = payload.authority;
      state.isLogin = payload.isLogin;
      console.log(state);
    },
  },
  actions: {
    async login(context, payload) {
      console.log("store action");
      let isLogin = null;
      let password = null;
      let authority = null;
      let token = null;

      await axios({
        method: "POST",
        url: "http://localhost:8080/getlogindata",
        data: {
          userID: payload.userID,
          userPassword: payload.password,
          token: "",
          authority: "",
        },
      })
        .then((response) => {
          password = response.data.userPassword;
          authority = response.data.authority;
          token = response.data.token;
        })
        .catch((error) => {
          console.log(error);
        });

      if (payload.userPassword === password) {
        console.log("here");
        isLogin = true;
      } else {
        isLogin = false;
      }
      context.commit("login", {
        userID: payload.userID,
        token: token,
        antuority: authority,
        isLogin,
      });
    },
  },
  getters: {
    getLoginState(state) {
      return state.isLogin;
    },
    getUserID(state) {
      return state.userID;
    }
  },
});

export default store;
