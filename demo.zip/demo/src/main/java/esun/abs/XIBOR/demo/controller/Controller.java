package esun.abs.XIBOR.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import esun.abs.XIBOR.demo.Dto.TermRateDto;
import esun.abs.XIBOR.demo.Dto.TermRateRelayDto;
import esun.abs.XIBOR.demo.Dto.UserDto;
import esun.abs.XIBOR.demo.Dto.UserRelayDto;
import esun.abs.XIBOR.demo.Bo.TermRateInputBo;
import esun.abs.XIBOR.demo.Bo.TermRateOutputBo;
import esun.abs.XIBOR.demo.Bo.UserInputBo;
import esun.abs.XIBOR.demo.Bo.UserOutputBo;
import esun.abs.XIBOR.demo.service.Service;

@CrossOrigin
@RestController
public class Controller {
	
	@Autowired
	Service service;
	
	@PostMapping(value= {"getlogindata"})
	public @ResponseBody UserRelayDto getLoginData(@RequestBody(required=false) UserDto userDto) {
		UserInputBo userInputBo = new UserInputBo();
		userInputBo.setUserID(userDto.getUserID());
		userInputBo.setUserPassword(userDto.getUserPassword());
		userInputBo.setToken(userDto.getToken());
		userInputBo.setAuthority(userDto.getAuthority());
		UserOutputBo userOutputBo = service.getLoginData(userInputBo);
		UserRelayDto userRelayDto = new UserRelayDto();
		userRelayDto.setUserID(userOutputBo.getUserID());
		userRelayDto.setUserPassword(userOutputBo.getUserPassword());
		userRelayDto.setToken(userOutputBo.getToken());
		userRelayDto.setAuthority(userOutputBo.getAuthority());
		
		return userRelayDto;
	}
	
	@PostMapping(value = {"getTermRatedata"})
	public @ResponseBody TermRateRelayDto getTermRateData(@RequestBody TermRateDto termRateDto) {
	    System.out.println(termRateDto.getValueDate());
	    TermRateInputBo termRateInputBo = new TermRateInputBo();
	    termRateInputBo.setFunction(termRateDto.getFunction());
	    termRateInputBo.setInterestRateID(termRateDto.getInterestRateID());
	    termRateInputBo.setCurrency(termRateDto.getCurrency());
        termRateInputBo.setValueDate(termRateDto.getValueDate());
        TermRateOutputBo termRateOutputBo=service.getTermRateData(termRateInputBo);
        TermRateRelayDto termRateRelayDto = new TermRateRelayDto();
        termRateRelayDto.setRateInformationList(termRateOutputBo.getRateInformationList());
        termRateRelayDto.setRateType(termRateOutputBo.getRateType());
	    return termRateRelayDto;
	}
	
	
}
