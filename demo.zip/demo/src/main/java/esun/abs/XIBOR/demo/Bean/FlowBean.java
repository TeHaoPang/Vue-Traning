package esun.abs.XIBOR.demo.Bean;

public class FlowBean {
    
    String ID;
    TermRateBean termRate;
    RateTypeBean rateType;
    RateInformationBean rateInformation;
    String userID;
    String status;
    String flow;
    
    public String getID() {
        return ID;
    }

    public void setID(String iD) {
        ID = iD;
    }
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFlow() {
        return flow;
    }

    public void setFlow(String flow) {
        this.flow = flow;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public RateInformationBean getRateInformation() {
        return rateInformation;
    }

    public void setRateInformation(RateInformationBean rateInformation) {
        this.rateInformation = rateInformation;
    }

    public RateTypeBean getRateType() {
        return rateType;
    }

    public void setRateType(RateTypeBean rateType) {
        this.rateType = rateType;
    }

    public TermRateBean getTermRate() {
        return termRate;
    }

    public void setTermRate(TermRateBean termRate) {
        this.termRate = termRate;
    }
}
