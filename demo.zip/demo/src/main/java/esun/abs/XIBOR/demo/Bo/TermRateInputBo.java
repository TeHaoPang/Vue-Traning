package esun.abs.XIBOR.demo.Bo;

import java.util.Date;
import java.util.List;

//import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import esun.abs.XIBOR.demo.Bean.RateInformationBean;
import esun.abs.XIBOR.demo.Bean.RateTypeBean;

public class TermRateInputBo {
    
    private String function;
    private String interestRateID;
    private String currency;
    
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")
    private Date valueDate;
    
    private RateTypeBean rateType;
    private List<RateInformationBean> rateInformationList;
    
    public String getFunction() {
        return function;
    }
    public void setFunction(String function) {
        this.function = function;
    }
    public String getInterestRateID() {
        return interestRateID;
    }
    public void setInterestRateID(String interestRateID) {
        this.interestRateID = interestRateID;
    }
    public String getCurrency() {
        return currency;
    }
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    
//    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    public Date getValueDate() {
        return valueDate;
    }
    
//    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    public void setValueDate(Date valueDate) {
        this.valueDate = valueDate;
    }
    public RateTypeBean getRateType() {
        return rateType;
    }
    public void setRateType(RateTypeBean rateType) {
        this.rateType = rateType;
    }
    public List<RateInformationBean> getRateInformationList() {
        return rateInformationList;
    }
    public void setRateInformationList(List<RateInformationBean> rateInformationList) {
        this.rateInformationList = rateInformationList;
    }
    
}
