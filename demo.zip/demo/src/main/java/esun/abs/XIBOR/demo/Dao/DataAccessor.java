package esun.abs.XIBOR.demo.Dao;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import esun.abs.XIBOR.demo.Bean.FlowBean;
import esun.abs.XIBOR.demo.Bean.ResponseBean;
import esun.abs.XIBOR.demo.Bo.TermRateInputBo;
import esun.abs.XIBOR.demo.Bo.UserOutputBo;

public class DataAccessor {

	private JdbcTemplate jdbcTemplate;
	
	public void setjdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public List<UserOutputBo> getLoginData(String userID) {

		Map<String, Object> result = new SimpleJdbcCall(jdbcTemplate).withCatalogName("PG_TEST_ABS_21662").withProcedureName("SP_GET_LOGIN_DATA")
		        .returningResultSet("O_USER_DATA", BeanPropertyRowMapper.newInstance(UserOutputBo.class))
                .execute(new MapSqlParameterSource().addValue("I_USER_ID",userID));
        @SuppressWarnings("unchecked")
        List<UserOutputBo> userOutputBoList = (List<UserOutputBo>) result.get("O_USER_DATA");
        System.out.println(userOutputBoList);

		return userOutputBoList;
		
		
	}

    public List<Map<String, Object>> getTermRateData(TermRateInputBo termRateInputBo) {
        System.out.println("getTermRateData");
        Map<String, Object> result = new SimpleJdbcCall(jdbcTemplate).withCatalogName("PG_TEST_ABS_21662").withProcedureName("SP_GET_TERMRATE_DATA")
                .execute(new MapSqlParameterSource().addValue("I_FUNCTION",termRateInputBo.getFunction())
                                                    .addValue("I_INTERESTRATE_ID",termRateInputBo.getInterestRateID())
                                                    .addValue("I_CURRENCY",termRateInputBo.getCurrency())
                                                    .addValue("I_VALUE_DATE",termRateInputBo.getValueDate()));
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> resultList = (List<Map<String, Object>>) result.get("OUT_TERMRATE_DATA");
        
        
        return resultList;
    }
    
    public ResponseBean addTermRateData(TermRateInputBo termRateInputBo) {
        System.out.println("add");
        try {
            new SimpleJdbcCall(jdbcTemplate).withCatalogName("PG_TEST_ABS_21662").withProcedureName("SP_ADD_TERMRATE_DATA")
            .execute(new MapSqlParameterSource().addValue("I_BIDRATE",termRateInputBo.getRateInformationList().get(0).getBidRate())
                                                .addValue("I_OFFERRATE",termRateInputBo.getRateInformationList().get(0).getOfferRate())
                                                .addValue("I_FUNCTION",termRateInputBo.getFunction())
                                                .addValue("I_INTERESTRATE_ID",termRateInputBo.getInterestRateID())
                                                .addValue("I_CURRENCY",termRateInputBo.getCurrency())
                                                .addValue("I_VALUEDATE",termRateInputBo.getValueDate())
                                                .addValue("I_TERM",termRateInputBo.getRateInformationList().get(0).getTerm())); 
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ResponseBean responseBean = new ResponseBean();
            responseBean.setMessage(e.getMessage());
            responseBean.setCode(0);
            return responseBean;
        }
        ResponseBean responseBean = new ResponseBean();
        responseBean.setMessage("成功");
        responseBean.setCode(1);
        return responseBean;
    }

    public ResponseBean updateTermRateData(TermRateInputBo termRateInputBo) {
        System.out.println("update");
        System.out.println(termRateInputBo.getRateInformationList().get(0).getkTenor());
        try {
            new SimpleJdbcCall(jdbcTemplate).withCatalogName("PG_TEST_ABS_21662").withProcedureName("SP_UPDATE_TERMRATE_DATA")
            .execute(new MapSqlParameterSource().addValue("I_RATE",termRateInputBo.getRateInformationList().get(0).getRate())
                                                .addValue("I_FUNCTION",termRateInputBo.getFunction())
                                                .addValue("I_INTERESTRATE_ID",termRateInputBo.getInterestRateID())
                                                .addValue("I_CURRENCY",termRateInputBo.getCurrency())
                                                .addValue("I_VALUEDATE",termRateInputBo.getValueDate())
                                                .addValue("I_KENTOR",termRateInputBo.getRateInformationList().get(0).getkTenor())); 
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ResponseBean responseBean = new ResponseBean();
            responseBean.setMessage(e.getMessage());
            responseBean.setCode(0);return responseBean;
        }
        ResponseBean responseBean = new ResponseBean();
        responseBean.setMessage("成功");
        responseBean.setCode(1);
        return responseBean;
    }

    public ResponseBean insertFlow(FlowBean flowBean) {
        new SimpleJdbcCall(jdbcTemplate).withCatalogName("PG_TEST_ABS_21662")
                                        .withProcedureName("SP_INSERT_FLOW")
                                        .execute(new MapSqlParameterSource().addValue("I_FLOW_ID",flowBean.getID())
                                                                            .addValue("I_FUNCTION",flowBean.getTermRate().getFunction())
                                                                            .addValue("I_INTERESTRATEID",flowBean.getTermRate().getInterestRateID())
                                                                            .addValue("I_CURRENCY",flowBean.getTermRate().getCurrency())
                                                                            .addValue("I_VALUEDATE",flowBean.getTermRate().getValueDate())
                                                                            .addValue("I_RATETYPE",flowBean.getRateType().getRateType())
                                                                            .addValue("I_BACKWARDTYPE",flowBean.getRateType().getBackwardType())
                                                                            .addValue("I_TERM",flowBean.getRateInformation().get(0).getTerm())
                                                                            .addValue("I_BIDRATE",flowBean.getRateInformation().get(0).getBidRate())
                                                                            .addValue("I_OFFERRATE",flowBean.getRateInformation().get(0).getOfferRate())
                                                                            .addValue("I_KTENOR",flowBean.getRateInformation().get(0).getkTenor())
                                                                            .addValue("I_RATE",flowBean.getRateInformation().get(0).getRate())
                                                                            .addValue("I_USER_ID",flowBean.getUserID())
                                                                            .addValue("I_STATUS",flowBean.getStatus())
                                                                            .addValue("I_FLOW",flowBean.getFlow())
                                                                            .addValue("I_PREVIOUSUSERID",flowBean.getPreviousUserID()));
        return null;
    }
    
    public List<Map<String, Object>> getFlowData(String ID) {
        Map<String, Object> result = new SimpleJdbcCall(jdbcTemplate).withCatalogName("PG_TEST_ABS_21662")
                                                                     .withProcedureName("SP_GET_FLOW_DATA")
                                                                     .execute(new MapSqlParameterSource().addValue("I_FLOW_ID",ID));
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> resultList = (List<Map<String, Object>>) result.get("O_FLOW_LIST");
        return resultList;
    }
    
    public List<Map<String, Object>> getFlowList(String userID) {
        Map<String, Object> result = new SimpleJdbcCall(jdbcTemplate).withCatalogName("PG_TEST_ABS_21662")
                                                                     .withProcedureName("SP_GET_FLOW_LIST")
                                                                     .execute(new MapSqlParameterSource().addValue("I_USER_ID",userID));
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> resultList = (List<Map<String, Object>>) result.get("O_FLOW_LIST");
        System.out.println(resultList);
        return resultList;
        
    }
    
    public ResponseBean updateFlowWithTerm(FlowBean flowBean) {
        new SimpleJdbcCall(jdbcTemplate).withCatalogName("PG_TEST_ABS_21662")
        .withProcedureName("SP_UPDATE_FLOW_WITH_TERM")
        .execute(new MapSqlParameterSource().addValue("I_BIDRATE",flowBean.getRateInformation().get(0).getBidRate())
                                            .addValue("I_OFFRATE",flowBean.getRateInformation().get(0).getOfferRate())
                                            .addValue("I_USER_ID",flowBean.getUserID())
                                            .addValue("I_STATUS",flowBean.getStatus())
                                            .addValue("I_FLOW",flowBean.getFlow())
                                            .addValue("I_PREVIOUSUSERID",flowBean.getPreviousUserID())
                                            .addValue("I_FLOW_ID",flowBean.getID())
                                            .addValue("I_TERM",flowBean.getRateInformation().get(0).getTerm()));
        return null;
    }

    public ResponseBean updateFlowWithkTenor(FlowBean flowBean) {
        new SimpleJdbcCall(jdbcTemplate).withCatalogName("PG_TEST_ABS_21662")
                                        .withProcedureName("SP_UPDATE_FLOW_WITH_KTENOR")
                                        .execute(new MapSqlParameterSource().addValue("I_RATE",flowBean.getRateInformation().get(0).getRate())
                                                                            .addValue("I_USER_ID",flowBean.getUserID())
                                                                            .addValue("I_STATUS",flowBean.getStatus())
                                                                            .addValue("I_FLOW",flowBean.getFlow())
                                                                            .addValue("I_PREVIOUSUSERID",flowBean.getPreviousUserID())
                                                                            .addValue("I_FLOW_ID",flowBean.getID())
                                                                            .addValue("I_KTENOR",flowBean.getRateInformation().get(0).getkTenor()));
        return null;
    }

	public List<Map<String, Object>> getNextUserList(String authority) {
        Map<String, Object> result = new SimpleJdbcCall(jdbcTemplate)
                .withCatalogName("PG_TEST_ABS_21662")
                .withProcedureName("SP_GET_NEXT_USER_LIST")
                .execute(new MapSqlParameterSource().addValue("I_AUTHORITY",authority));
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> userList = (List<Map<String, Object>>) result.get("O_USER_LIST");
        System.out.println(userList);
		return userList;
	}

    public ResponseBean delete(String ID) {
        System.out.println(ID);
        new SimpleJdbcCall(jdbcTemplate).withCatalogName("PG_TEST_ABS_21662")
        .withProcedureName("SP_DELETE")
        .execute(new MapSqlParameterSource().addValue("I_FLOW_ID",ID));
        
        return null;
    }

    public ResponseBean reject(FlowBean flowBean) {
        new SimpleJdbcCall(jdbcTemplate).withCatalogName("PG_TEST_ABS_21662")
        .withProcedureName("SP_REJECT")
        .execute(new MapSqlParameterSource().addValue("I_USER_ID",flowBean.getUserID())
                                            .addValue("I_FLOW",flowBean.getFlow())
                                            .addValue("I_PREVIOUSUSERID",flowBean.getPreviousUserID())
                                            .addValue("I_ID",flowBean.getID()));
        return null;
    }

    public List<Map<String, Object>> getFlowDetail(String flowID) {
        Map<String, Object> result = new SimpleJdbcCall(jdbcTemplate)
                                            .withCatalogName("PG_TEST_ABS_21662")
                                            .withProcedureName("SP_GET_FLOW_DETAIL")
                                            .execute(new MapSqlParameterSource().addValue("I_FLOW_ID",flowID));
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> resultList = (List<Map<String, Object>>) result.get("O_FLOW");
        System.out.println("sp test");
        System.out.println(resultList);
        return resultList;
    }
    
    public String getFlowString (String flowID) {
       return new SimpleJdbcCall(jdbcTemplate)
               .withCatalogName("PG_TEST_ABS_21662")
               .withProcedureName("SP_GET_FLOW_STRING")
               .execute(new MapSqlParameterSource().addValue("I_FLOW_ID",flowID))
               .get("O_FLOW_STRING").toString();
    }
}
