package esun.abs.XIBOR.demo.Dao;

import java.util.List;
import java.util.Map;
import java.sql.Types;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import esun.abs.XIBOR.demo.Bo.TermRateInputBo;
import esun.abs.XIBOR.demo.Bo.UserOutputBo;

public class DataAccessor {

	private JdbcTemplate jdbcTemplate;

	public void setjdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public List<UserOutputBo> getLoginData(String userID) {
		List<UserOutputBo> userOutputBoList = (List<UserOutputBo>)this.jdbcTemplate.query(
				"SELECT USERID, USERPASSWORD, TOKEN, AUTHORITY FROM TEST_ABS_LOGIN_DATA_21662 WHERE USERID = ?", 
				new Object[] {userID},
				new int[] {Types.VARCHAR},
				new BeanPropertyRowMapper<UserOutputBo>(UserOutputBo.class));
		return userOutputBoList;
	}

    public List<Map<String, Object>> getTermRateData(TermRateInputBo termRateInputBo) {
        System.out.println(termRateInputBo.getValueDate());
        List<Map<String, Object>> resultList = this.jdbcTemplate.queryForList(
                "SELECT RATETYPE,"
                + "     TERM, "
                + "     BIDRATE, "
                + "     OFFERRATE "
              + "FROM   TEST_ABS_XIBOR_21662 "
              + "WHERE  FUNCTION = ? "
              + "AND    INTERESTRATEID = ? "
              + "AND    CURRENCY = ? "
              + "AND    VALUEDATE = ?",
                new Object[] { termRateInputBo.getFunction(),
                               termRateInputBo.getInterestRateID(), 
                               termRateInputBo.getCurrency(), 
                               termRateInputBo.getValueDate()},
                new int[] {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DATE});
        System.out.println(resultList);
        return resultList;
    }

}
