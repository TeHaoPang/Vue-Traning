package esun.abs.XIBOR.demo.Dao;

import java.util.List;
import java.util.Map;
import java.sql.Types;


import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import esun.abs.XIBOR.demo.Bean.FlowBean;
import esun.abs.XIBOR.demo.Bean.ResponseBean;
import esun.abs.XIBOR.demo.Bo.TermRateInputBo;
import esun.abs.XIBOR.demo.Bo.UserOutputBo;

public class DataAccessor {

	private JdbcTemplate jdbcTemplate;

	public void setjdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public List<UserOutputBo> getLoginData(String userID) {
		List<UserOutputBo> userOutputBoList = (List<UserOutputBo>)this.jdbcTemplate.query(
				"SELECT USERID, USERPASSWORD, TOKEN, AUTHORITY FROM TEST_ABS_LOGIN_DATA_21662 WHERE USERID = ?", 
				new Object[] {userID},
				new int[] {Types.VARCHAR},
				new BeanPropertyRowMapper<UserOutputBo>(UserOutputBo.class));
		return userOutputBoList;
	}

    public List<Map<String, Object>> getTermRateData(TermRateInputBo termRateInputBo) {
        System.out.println(termRateInputBo.getValueDate());
        List<Map<String, Object>> resultList = this.jdbcTemplate.queryForList(
                "SELECT RATETYPE,"
                + "     BACKWARDTYPE,"
                + "     TERM, "
                + "     BIDRATE, "
                + "     OFFERRATE, "
                + "     KTENOR, " 
                + "     RATE FROM   TEST_ABS_XIBOR_21662 "
              + "WHERE  FUNCTION = ? "
              + "AND    INTERESTRATEID = ? "
              + "AND    CURRENCY = ? "
              + "AND    VALUEDATE = ?",
                new Object[] { termRateInputBo.getFunction(),
                               termRateInputBo.getInterestRateID(), 
                               termRateInputBo.getCurrency(), 
                               termRateInputBo.getValueDate()},
                new int[] {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.DATE});
        System.out.println(resultList);
        return resultList;
    }
    
    public ResponseBean addTermRateData(TermRateInputBo termRateInputBo) {
        System.out.println("add");
        try {
            this.jdbcTemplate.update(
                "UPDATE TEST_ABS_XIBOR_21662 "
                + "SET BIDRATE = ?, OFFERRATE=? "
                + "WHERE FUNCTION =? "
                + "AND INTERESTRATEID=? "
                + "AND CURRENCY = ? "
                + "AND VALUEDATE = ? "
                + "AND TERM = ?",
                  termRateInputBo.getRateInformationList().get(0).getBidRate(),
                  termRateInputBo.getRateInformationList().get(0).getOfferRate(),
                  termRateInputBo.getFunction(),
                  termRateInputBo.getInterestRateID(), 
                  termRateInputBo.getCurrency(), 
                  termRateInputBo.getValueDate(),
                  termRateInputBo.getRateInformationList().get(0).getTerm()
                    );
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ResponseBean responseBean = new ResponseBean();
            responseBean.setMessage(e.getMessage());
            responseBean.setCode(0);
            return responseBean;
        }
        ResponseBean responseBean = new ResponseBean();
        responseBean.setMessage("成功");
        responseBean.setCode(1);
        return responseBean;
    }

    public ResponseBean updateTermRateData(TermRateInputBo termRateInputBo) {
        System.out.println("update");
        try {
            this.jdbcTemplate.update(
                    "UPDATE TEST_ABS_XIBOR_21662 "
                  + "SET RATE = ?"
                  + "WHERE FUNCTION =?"
                  + "AND INTERESTRATEID=?"
                  + "AND CURRENCY = ? "
                  + "AND VALUEDATE = ?"
                  + "AND KTENOR = ?", 
                  termRateInputBo.getRateInformationList().get(0).getRate(),
                  termRateInputBo.getFunction(),
                  termRateInputBo.getInterestRateID(), 
                  termRateInputBo.getCurrency(),
                  termRateInputBo.getValueDate(),
                  termRateInputBo.getRateInformationList().get(0).getkTenor()
                  );
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ResponseBean responseBean = new ResponseBean();
            responseBean.setMessage(e.getMessage());
            responseBean.setCode(0);return responseBean;
        }
        ResponseBean responseBean = new ResponseBean();
        responseBean.setMessage("成功");
        responseBean.setCode(1);
        return responseBean;
    }

    public ResponseBean insertFlow(FlowBean flowBean) {
        this.jdbcTemplate.update(
                "INSERT INTO TEST_ABS_FLOW_21662"
                + "(ID,"
                + "FUNCTION,"
                + "INTERESTRATEID,"
                + "CURRENCY,"
                + "VALUEDATE,"
                + "RATETYPE,"
                + "BACKWARDTYPE,"
                + "TERM,"
                + "BIDRATE,"
                + "OFFERRATE,"
                + "KTENOR,"
                + "RATE,"
                + "USERID,"
                + "STATUS,"
                + "FLOW)"
                + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                flowBean.getID(),
                flowBean.getTermRate().getFunction(),
                flowBean.getTermRate().getInterestRateID(),
                flowBean.getTermRate().getCurrency(),
                flowBean.getTermRate().getValueDate(),
                flowBean.getRateType().getRateType(),
                flowBean.getRateType().getBackwardType(),
                flowBean.getRateInformation().get(0).getTerm(),
                flowBean.getRateInformation().get(0).getBidRate(),
                flowBean.getRateInformation().get(0).getOfferRate(),
                flowBean.getRateInformation().get(0).getkTenor(),
                flowBean.getRateInformation().get(0).getRate(),
                flowBean.getUserID(),
                flowBean.getStatus(),
                flowBean.getFlow()
                );
        return null;
    }
    
    public List<Map<String, Object>> getFlowData(String ID) {
        List<Map<String, Object>> resultList = this.jdbcTemplate.queryForList(
                "SELECT * FROM TEST_ABS_FLOW_21662 WHERE ID = ? ",
                new Object[] {ID},
                new int[] {Types.VARCHAR});
        System.out.println(resultList);
        return resultList;
    }
    
    public ResponseBean updateFlowWithTerm(FlowBean flowBean) {
        this.jdbcTemplate.update(
                "UPDATE TEST_ABS_FLOW_21662"
                + "BIDRATE = ?,"
                + "OFFERRATE = ?,"
                + "USERID = ?,"
                + "STATUS = ?,"
                + "FLOW = ?"
                + "WHERE ID = ? AND TERM = ?",
                flowBean.getRateInformation().get(0).getBidRate(),
                flowBean.getRateInformation().get(0).getOfferRate(),
                flowBean.getUserID(),
                flowBean.getStatus(),
                flowBean.getFlow(),
                flowBean.getID(),
                flowBean.getRateInformation().get(0).getTerm()
                );
        return null;
    }

    public ResponseBean updateFlowWithkTenor(FlowBean flowBean) {
            this.jdbcTemplate.update(
                    "UPDATE TEST_ABS_FLOW_21662"
                    + "RATE = ?,"
                    + "USERID = ?,"
                    + "STATUS = ?,"
                    + "FLOW = ?"
                    + "WHERE ID = ? "
                    + "AND KTENOR = ?",
                    flowBean.getRateInformation().get(0).getRate(),
                    flowBean.getUserID(),
                    flowBean.getStatus(),
                    flowBean.getFlow(),
                    flowBean.getID(),
                    flowBean.getRateInformation().get(0).getkTenor()
                    );
            return null;
    }

}
