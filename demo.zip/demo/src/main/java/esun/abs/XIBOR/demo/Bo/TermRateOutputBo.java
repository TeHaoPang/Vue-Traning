package esun.abs.XIBOR.demo.Bo;

import java.util.List;

import esun.abs.XIBOR.demo.Bean.RateInformationBean;
import esun.abs.XIBOR.demo.Bean.RateTypeBean;

public class TermRateOutputBo {
    
    private RateTypeBean rateType;
    private List<RateInformationBean> rateInformationList;
    
    public List<RateInformationBean> getRateInformationList() {
        return rateInformationList;
    }
    public void setRateInformationList(List<RateInformationBean> rateInformationList) {
        this.rateInformationList = rateInformationList;
    }
    public RateTypeBean getRateType() {
        return rateType;
    }
    public void setRateType(RateTypeBean rateType) {
        this.rateType = rateType;
    }
}
