package esun.abs.XIBOR.demo.Bean;

public class RateTypeBean {
    
    private String rateType;
    private String backwardType;
    
    public String getRateType() {
        return rateType;
    }
    public void setRateType(String rateType) {
        this.rateType = rateType;
    }
    public String getBackwardType() {
        return backwardType;
    }
    public void setBackwardType(String backwardType) {
        this.backwardType = backwardType;
    }
    
    
}
