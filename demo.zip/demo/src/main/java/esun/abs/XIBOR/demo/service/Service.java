package esun.abs.XIBOR.demo.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import esun.abs.XIBOR.demo.Bean.RateInformationBean;
import esun.abs.XIBOR.demo.Bean.RateTypeBean;
import esun.abs.XIBOR.demo.Bo.TermRateInputBo;
import esun.abs.XIBOR.demo.Bo.TermRateOutputBo;
import esun.abs.XIBOR.demo.Bo.UserInputBo;
import esun.abs.XIBOR.demo.Bo.UserOutputBo;
import esun.abs.XIBOR.demo.Dao.DataAccessor;

public class Service {
	private DataAccessor dataAccessor;

	public void setDataAccessor(DataAccessor dataAccessor) {
		this.dataAccessor = dataAccessor;
	}

	public UserOutputBo getLoginData(UserInputBo userInputBo) {
		List<UserOutputBo> UserOutputBoList= this.dataAccessor.getLoginData(userInputBo.getUserID());
		return UserOutputBoList.get(0);
	}

    public TermRateOutputBo getTermRateData(TermRateInputBo termRateInputBo) {
        List<Map<String, Object>> resultList = this.dataAccessor.getTermRateData(termRateInputBo);
        TermRateOutputBo termRateOutputBo = new TermRateOutputBo();
        RateTypeBean rateType = new RateTypeBean();
        
        if (termRateInputBo.getFunction().equals("1")) {
            rateType.setRateType(resultList.get(0).get("RATETYPE").toString());
        } else {
            rateType.setRateType(resultList.get(0).get("RATETYPE").toString());
            rateType.setBackwardType(resultList.get(0).get("BACKWARDTYPE").toString());
        };
        termRateOutputBo.setRateType(rateType);
        
        List<RateInformationBean> rateInformationList = new ArrayList<>() ;
        for(Map<String, Object> item :resultList) {
            RateInformationBean rateInformationBean = new RateInformationBean();
            if(termRateInputBo.getFunction().equals("1")) {
                rateInformationBean.setTerm(item.get("TERM").toString());
                rateInformationBean.setBidRate(new BigDecimal(item.get("BIDRATE").toString()));
                rateInformationBean.setOfferRate(new BigDecimal(item.get("OFFERRATE").toString()));
            }else {
                rateInformationBean.setkTenor((Integer)item.get("KTENOR"));
                rateInformationBean.setRate(new BigDecimal(item.get("RATE").toString()));
     
            };
            rateInformationList.add(rateInformationBean);
        }
        
        termRateOutputBo.setRateInformationList(rateInformationList);
        return termRateOutputBo;
    }
}
