package esun.abs.XIBOR.demo.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import esun.abs.XIBOR.demo.Bean.FlowBean;
import esun.abs.XIBOR.demo.Bean.RateInformationBean;
import esun.abs.XIBOR.demo.Bean.RateTypeBean;
import esun.abs.XIBOR.demo.Bo.TermRateInputBo;
import esun.abs.XIBOR.demo.Bo.TermRateOutputBo;
import esun.abs.XIBOR.demo.Bo.UserInputBo;
import esun.abs.XIBOR.demo.Bo.UserOutputBo;
import esun.abs.XIBOR.demo.Dao.DataAccessor;
import esun.abs.XIBOR.demo.Bean.ResponseBean;


public class Service {
	private DataAccessor dataAccessor;

	public void setDataAccessor(DataAccessor dataAccessor) {
		this.dataAccessor = dataAccessor;
	}

	public UserOutputBo getLoginData(UserInputBo userInputBo) {
		List<UserOutputBo> UserOutputBoList= this.dataAccessor.getLoginData(userInputBo.getUserID());
		return UserOutputBoList.get(0);
	}

    public TermRateOutputBo getTermRateData(TermRateInputBo termRateInputBo) {
        List<Map<String, Object>> resultList = this.dataAccessor.getTermRateData(termRateInputBo);
        TermRateOutputBo termRateOutputBo = new TermRateOutputBo();
        RateTypeBean rateType = new RateTypeBean();
        
        if (resultList.get(0).get("RATETYPE").toString().equals("1")) {
            rateType.setRateType(resultList.get(0).get("RATETYPE").toString());
        } else {
            rateType.setRateType(resultList.get(0).get("RATETYPE").toString());
            rateType.setBackwardType(resultList.get(0).get("BACKWARDTYPE").toString());
        };
        termRateOutputBo.setRateType(rateType);
        
        List<RateInformationBean> rateInformationList = new ArrayList<>() ;
        for(Map<String, Object> item :resultList) {
            RateInformationBean rateInformationBean = new RateInformationBean();
            
            if(rateType.getRateType().equals("1")) {
                rateInformationBean.setTerm(item.get("TERM").toString());
                rateInformationBean.setBidRate(new BigDecimal(item.get("BIDRATE").toString()));
                rateInformationBean.setOfferRate(new BigDecimal(item.get("OFFERRATE").toString()));
            }else if (rateType.getRateType().equals("2") && "1".equals(rateType.getBackwardType())) {
                rateInformationBean.setTerm(item.get("TERM").toString());
                rateInformationBean.setBidRate(new BigDecimal(item.get("BIDRATE").toString()));
                rateInformationBean.setOfferRate(new BigDecimal(item.get("OFFERRATE").toString()));
            }
            else if (rateType.getRateType().equals("2") && "2".equals(rateType.getBackwardType())) {
                rateInformationBean.setkTenor(new BigDecimal(item.get("KTENOR").toString()));
                rateInformationBean.setRate(new BigDecimal(item.get("RATE").toString()));
            };
            rateInformationList.add(rateInformationBean);
        }
        
        termRateOutputBo.setRateInformationList(rateInformationList);
        return termRateOutputBo;
    }

    public ResponseBean updateTermRateData(TermRateInputBo termRateInputBo) {
        ResponseBean responseBean = new ResponseBean();
        for(RateInformationBean item :termRateInputBo.getRateInformationList()) {
            TermRateInputBo tempTermRateInputBo = new TermRateInputBo();
            List<RateInformationBean> singleRateInformationList = new ArrayList<>();
            singleRateInformationList.add(item);
            
            tempTermRateInputBo.setFunction(termRateInputBo.getFunction());
            tempTermRateInputBo.setInterestRateID(termRateInputBo.getInterestRateID());
            tempTermRateInputBo.setCurrency(termRateInputBo.getCurrency());
            tempTermRateInputBo.setValueDate(termRateInputBo.getValueDate());
            tempTermRateInputBo.setRateType(termRateInputBo.getRateType());
            tempTermRateInputBo.setRateInformationList(singleRateInformationList);
            if (tempTermRateInputBo.getRateType().getBackwardType().equals("2")) {
                responseBean=this.dataAccessor.updateTermRateData(tempTermRateInputBo);
            }else {
                responseBean=this.dataAccessor.addTermRateData(tempTermRateInputBo);
            }
        }
        
        return responseBean;
        
    }

    public ResponseBean submit(FlowBean flowBean) {
        ResponseBean responseBean = new ResponseBean();
        int flag = 0;
        if (flowBean.getID() == null) {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            flowBean.setID(dtf.format(LocalDateTime.now()));
            flowBean.setFlow("E-W");
            flag = 1;
        } else {
            System.out.println(flowBean.getID());
            flowBean.setFlow(flowBean.getFlow()+"E-W");
        }
        flowBean.setStatus("Wait For Authorization");
        for (RateInformationBean item: flowBean.getRateInformation()) {
            List<RateInformationBean> templist = new ArrayList<>();
            templist.add(item);
            flowBean.setRateInformation(templist);
            if (flag == 1) {
            	responseBean = this.dataAccessor.insertFlow(flowBean);
            }else if (item.getkTenor() == null) {
                responseBean = this.dataAccessor.updateFlowWithTerm(flowBean);
            } else if (item.getTerm() == null) {
                responseBean = this.dataAccessor.updateFlowWithkTenor(flowBean);
            }
        }
        return responseBean;
    }

	public List<Map<String, Object>> getNextUserList(String authority) {
		List<Map<String, Object>> userList = this.dataAccessor.getNextUserList(authority);
		return userList;
	}
}
