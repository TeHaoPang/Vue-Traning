package esun.abs.XIBOR.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Date;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import esun.abs.XIBOR.demo.Bean.RateTypeBean;
import esun.abs.XIBOR.demo.Bo.TermRateInputBo;
import esun.abs.XIBOR.demo.Bo.TermRateOutputBo;
import esun.abs.XIBOR.demo.Bo.UserInputBo;
import esun.abs.XIBOR.demo.Bo.UserOutputBo;
import esun.abs.XIBOR.demo.Dao.DataAccessor;
import esun.abs.XIBOR.demo.service.Service;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
public class DemoApplicationTests {

	@InjectMocks
	private Service service;
	
	@Mock
	private DataAccessor dataAccessor;
		
	@Test
	public void getLoginData() {
		List<UserOutputBo> UserOutputBoList = new ArrayList<UserOutputBo>();
		UserOutputBo testbean2 = new UserOutputBo();
		testbean2.setUserID("21662");
		testbean2.setUserPassword("12345");
		UserOutputBoList.add(testbean2);
		
		UserInputBo testbean = new UserInputBo();
		testbean.setUserID("21662");
		
		System.out.println(testbean.getUserID());
		System.out.println("123");
		System.out.println(dataAccessor.getLoginData(testbean.getUserID()));
		Mockito.when(dataAccessor.getLoginData(testbean.getUserID())).thenReturn(UserOutputBoList);
		UserOutputBo testbean3 = service.getLoginData(testbean);
		
		assertEquals(testbean3.getUserID(),testbean.getUserID());
	}

	@Test
	public void getTermRateData() {
		TermRateInputBo termRateInputBo = new TermRateInputBo();
		termRateInputBo.setFunction("1");
		termRateInputBo.setInterestRateID("10");
		termRateInputBo.setCurrency("AUD");
		
		List<Map<String,Object>> resultList = new ArrayList<>();
		List<Map<String,Object>> resultList2 = new ArrayList<>();
		Map<String,Object> map = new HashMap<>();
		map.put("RATETYPE","1");
		map.put("TERM","5");
		map.put("BIDRATE","1.0");
		map.put("OFFERRATE","1.5");
		resultList.add(map);
		resultList2.add(map);
		Mockito.when(dataAccessor.getTermRateData(termRateInputBo)).thenReturn(resultList);
		
		TermRateOutputBo termRateOutputBo = service.getTermRateData(termRateInputBo);
		assertEquals(resultList2,resultList);
	}

}
