package esun.abs.XIBOR.demo;

import java.util.ArrayList;
import java.util.List;


import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import esun.abs.XIBOR.demo.Bo.UserInputBo;
import esun.abs.XIBOR.demo.Bo.UserOutputBo;
import esun.abs.XIBOR.demo.Dao.DataAccessor;
import esun.abs.XIBOR.demo.service.Service;

@RunWith(MockitoJUnitRunner.class)
//@SpringBootTest
public class DemoApplicationTests {

	@Autowired
	private Service service;
	
	@InjectMocks
	private DataAccessor dataAccessor;
		
	@Test
	public void getLoginData() {
		List<UserOutputBo> UserOutputBoList = new ArrayList<UserOutputBo>();
		UserOutputBo testbean2 = new UserOutputBo();
		testbean2.setUserID("21662");
		testbean2.setUserPassword("12345");
		UserOutputBoList.add(testbean2);
		
		UserInputBo testbean = new UserInputBo();
		testbean.setUserID("21662");
		
		System.out.println(testbean.getUserID());
		System.out.println("123");
		System.out.println(dataAccessor.getLoginData(testbean.getUserID()));
		Mockito.when(dataAccessor.getLoginData(testbean.getUserID())).thenReturn(UserOutputBoList);
		UserOutputBo testbean3 = service.getLoginData(testbean);
		
		assertEquals(testbean3,testbean);
	}



}
