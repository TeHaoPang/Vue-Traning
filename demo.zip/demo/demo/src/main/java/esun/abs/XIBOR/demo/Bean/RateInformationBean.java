package esun.abs.XIBOR.demo.Bean;

import java.math.BigDecimal;

public class RateInformationBean {
    
    private String term;
    private BigDecimal bidRate;
    private BigDecimal offerRate;
    private BigDecimal kTenor;
    private BigDecimal rate;
    
    public String getTerm() {
        return term;
    }
    public void setTerm(String term) {
        this.term = term;
    }
    public BigDecimal getBidRate() {
        return bidRate;
    }
    public void setBidRate(BigDecimal bidRate) {
        this.bidRate = bidRate;
    }
    public BigDecimal getOfferRate() {
        return offerRate;
    }
    public void setOfferRate(BigDecimal offerRate) {
        this.offerRate = offerRate;
    }
    public BigDecimal getkTenor() {
        return kTenor;
    }
    public void setkTenor(BigDecimal kTenor) {
        this.kTenor = kTenor;
    }
    public BigDecimal getRate() {
        return rate;
    }
    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }
    
}
